// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("cross mingw64\n", stdout);
  return lionss_run_workload("cross-mingw64");
}
