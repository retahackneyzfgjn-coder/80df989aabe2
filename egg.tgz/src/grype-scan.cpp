// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("grype scan"); }
int main(){
  announce();
  return lionss_run_workload("grype-scan");
}
