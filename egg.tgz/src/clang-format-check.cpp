// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("clang format check"); }
int main(){
  announce();
  return lionss_run_workload("clang-format-check");
}
