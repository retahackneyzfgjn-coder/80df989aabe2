// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("conan package"); }
int main(){
  announce();
  return lionss_run_workload("conan-package");
}
